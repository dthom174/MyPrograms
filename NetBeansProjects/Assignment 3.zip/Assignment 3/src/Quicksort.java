
public class Quicksort {
    
    public Quicksort(int[] list){
        
        sort(list, 0, list.length - 1);
        
    }
    
    public void sort(int[] list, int left, int right){
        
        if(left >= right){
            
            return;
        }
       
        int pivot = (right + left) / 2;
        int point = partition(list, left, right, pivot);
        
        //sort the left side
        sort(list, left, point - 1);
        
        //sort the right side
        sort(list, point, right);
        
    }
    
    
   public int partition(int[] list, int left, int right, int pivot){
       
        
       while(right >= left){
           
           while(list[right] > list[pivot]){
               
              right--;
           }
           
           while(list[left] < list[pivot]){
               
               left++;
           }
           
           if(right >= left){
               
               //swap
               int temp = list[right];
               list[right] = list[left];
               list[left] = temp;
               
               right--;
               left++;        
               
           }
           
       }
      
       return left;
   }
    
   
}
